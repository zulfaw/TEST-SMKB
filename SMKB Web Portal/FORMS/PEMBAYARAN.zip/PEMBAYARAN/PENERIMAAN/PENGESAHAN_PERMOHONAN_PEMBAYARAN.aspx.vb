﻿Imports System.Web.Services
Imports Newtonsoft.Json
Imports System.Data

Public Class PENGESAHAN_PERMOHONAN_PEMBAYARAN
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim A = "ayam"
    End Sub


End Class
