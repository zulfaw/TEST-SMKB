﻿Imports System.Web.Services
Imports Newtonsoft.Json
Imports System.Data

Public Class PENYEDIAAN_BAUCAR
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub


End Class